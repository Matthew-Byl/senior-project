﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace Mankalah
{
    /*****************************************************************
     * A Mankalah player.  This is the base class for players.
     * You'll derive a player from this base. Be sure your player
     * works correctly both as TOP and as BOTTOM.
     *****************************************************************/
    public abstract class Player
    {
        private String name;
        private int position;

        //constructor. Parameters are position (TOP/BOTTOM) and name
        public Player(int pos, String n) { 
            name = n;
            position = pos; 
            Console.Write("Player " + name + " playing on ");
            if (pos == Board.TOP) Console.WriteLine("top.");
            if (pos == Board.BOTTOM) Console.WriteLine("bottom.");
            if (pos != Board.TOP && position != Board.BOTTOM) {
                Console.Write("...an illegal side of the board.");
	            Environment.Exit(1);
            }
        }

        /*
         * Evaluate: return a number saying how much we like this board. 
         * TOP is MAX, so positive scores should be better for TOP.
         * This default just counts the score so far. Override to improve!
         */
        public virtual int evaluate(Board b)
        {
            return b.stonesAt(13) - b.stonesAt(6);
        }

        public String getName() { return name; }

        /*
         * Override with your own choosemove function
         */
        public abstract int chooseMove(Board b);

        /*
         * Override with your own personalized gloat.
         */
        public virtual void gloat() { Console.WriteLine("I win."); }
    }
}
